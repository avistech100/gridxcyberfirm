<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/admin_layout.php';
admin_required();
set_active_nav('dashboard');

$db = get_db();

// Counts for dashboard cards
$user_count   = $db->query('SELECT COUNT(*) FROM user_gridxuser')->fetchColumn();
$tx_count     = $db->query('SELECT COUNT(*) FROM user_trasaction')->fetchColumn();
$refund_count = $db->query('SELECT COUNT(*) FROM refund_refund')->fetchColumn();
$group_count  = $db->query('SELECT COUNT(*) FROM auth_group')->fetchColumn();

// Recent actions (last 5 users & transactions)
$recent_users = $db->query('SELECT id, username, email, date_joined FROM user_gridxuser ORDER BY date_joined DESC LIMIT 5')->fetchAll();
$recent_tx    = $db->query('SELECT t.id, u.username, t.amount, t.is_approved, t.payment_method FROM user_trasaction t JOIN user_gridxuser u ON u.id=t.user_id ORDER BY t.id DESC LIMIT 5')->fetchAll();

admin_head('Dashboard');
admin_body_open('/admin/');
admin_content_header('Dashboard', ['Dashboard' => '']);
?>

<?= show_flash() ?>

<!-- STAT CARDS -->
<div class="row">
    <div class="col-lg-3 col-6">
        <div class="small-box bg-info">
            <div class="inner"><h3><?= $user_count ?></h3><p>Users</p></div>
            <div class="icon"><i class="fas fa-users"></i></div>
            <a href="/admin/users.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
        </div>
    </div>
    <div class="col-lg-3 col-6">
        <div class="small-box bg-success">
            <div class="inner"><h3><?= $tx_count ?></h3><p>Transactions</p></div>
            <div class="icon"><i class="fas fa-exchange-alt"></i></div>
            <a href="/admin/transactions.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
        </div>
    </div>
    <div class="col-lg-3 col-6">
        <div class="small-box bg-warning">
            <div class="inner"><h3><?= $refund_count ?></h3><p>Refunds</p></div>
            <div class="icon"><i class="fas fa-undo"></i></div>
            <a href="/admin/refunds.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
        </div>
    </div>
    <div class="col-lg-3 col-6">
        <div class="small-box bg-danger">
            <div class="inner"><h3><?= $group_count ?></h3><p>Groups</p></div>
            <div class="icon"><i class="fas fa-layer-group"></i></div>
            <a href="/admin/groups.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
        </div>
    </div>
</div>

<!-- DASHBOARD CONTENT CARDS (exact Jazzmin layout) -->
<div class="row">
    <div class="col-lg-9 col-12">
        <div class="row">

            <!-- Authentication and Authorization -->
            <div class="col-md-6 col-sm-12">
                <div class="card mb-3">
                    <div class="card-header"><h5 class="m-0">Authentication and Authorization</h5></div>
                    <div class="card-body">
                        <table class="table table-sm" role="table">
                            <tbody>
                                <tr>
                                    <td><a href="/admin/groups.php">Groups</a></td>
                                    <td>
                                        <div class="btn-group float-end">
                                            <a href="/admin/groups.php?action=add" class="btn btn-sm btn-success">Add</a>
                                            <a href="/admin/groups.php" class="btn btn-sm btn-info">Change</a>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Refund -->
                <div class="card mb-3">
                    <div class="card-header"><h5 class="m-0">Refund</h5></div>
                    <div class="card-body">
                        <table class="table table-sm" role="table">
                            <tbody>
                                <tr>
                                    <td><a href="/admin/refunds.php">Refunds</a></td>
                                    <td>
                                        <div class="btn-group float-end">
                                            <a href="/admin/refunds.php?action=add" class="btn btn-sm btn-success">Add</a>
                                            <a href="/admin/refunds.php" class="btn btn-sm btn-info">Change</a>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- User -->
                <div class="card mb-3">
                    <div class="card-header"><h5 class="m-0">User</h5></div>
                    <div class="card-body">
                        <table class="table table-sm" role="table">
                            <tbody>
                                <tr>
                                    <td><a href="/admin/transactions.php">Trasactions</a></td>
                                    <td>
                                        <div class="btn-group float-end">
                                            <a href="/admin/transactions.php?action=add" class="btn btn-sm btn-success">Add</a>
                                            <a href="/admin/transactions.php" class="btn btn-sm btn-info">Change</a>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td><a href="/admin/users.php">Users</a></td>
                                    <td>
                                        <div class="btn-group float-end">
                                            <a href="/admin/users.php?action=add" class="btn btn-sm btn-success">Add</a>
                                            <a href="/admin/users.php" class="btn btn-sm btn-info">Change</a>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- RECENT ACTIONS -->
    <div class="col-lg-3 col-12">
        <div class="card">
            <div class="card-header"><h5 class="m-0">Recent Actions</h5></div>
            <div class="card-body p-0">
                <ul class="list-group list-group-flush">
                    <?php foreach ($recent_users as $u): ?>
                    <li class="list-group-item">
                        <a href="/admin/users.php?action=edit&id=<?= $u['id'] ?>">
                            <i class="fas fa-user me-1"></i> <?= e($u['username']) ?>
                        </a>
                        <small class="text-muted d-block">User</small>
                    </li>
                    <?php endforeach; ?>
                    <?php foreach ($recent_tx as $t): ?>
                    <li class="list-group-item">
                        <a href="/admin/transactions.php?action=edit&id=<?= $t['id'] ?>">
                            <i class="fas fa-exchange-alt me-1"></i>
                            <?= e($t['username']) ?> $<?= e($t['amount']) ?>
                        </a>
                        <small class="text-muted d-block"><?= e(ucfirst($t['is_approved'])) ?></small>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </div>
</div>

<?php admin_footer(); ?>
